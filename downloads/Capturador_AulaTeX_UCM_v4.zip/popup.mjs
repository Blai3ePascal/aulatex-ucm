import {capturePage} from './capture.mjs';
const $=id=>document.getElementById(id);let payload=null;
$('capture').onclick=async()=>{
 $('capture').disabled=true;$('copy').disabled=true;$('save').disabled=true;payload=null;$('preview').replaceChildren();
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id)throw Error('No hay pestaña activa.');
  const [result]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:capturePage});
  if(!result?.result?.items?.length)throw Error('No hay referencias que capturar. Usa la exportación BibTeX/RIS de esta fuente.');
  payload=result.result;
  for(const item of payload.items){const row=document.createElement('article'),title=document.createElement('strong'),p=document.createElement('p');title.textContent=item.title||'Sin título';p.textContent=(item.author||[]).map(a=>a.literal||[a.given,a.family].filter(Boolean).join(' ')).join('; ')||'Autor no indicado';row.append(title,p);$('preview').append(row);}
  $('status').textContent=payload.items.length+' fichas capturadas. Revisa su contenido antes de citarlas. '+(payload.warnings||[]).join(' ');$('copy').disabled=false;$('save').disabled=false;
 }catch(e){$('status').textContent='No se pudo capturar: '+e.message;}finally{$('capture').disabled=false;}
};
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText(JSON.stringify(payload,null,2));$('status').textContent='Captura copiada. Pégala en Bibliografía del editor.';}catch(e){$('status').textContent='Portapapeles no disponible. Utiliza Guardar JSON.';}};
$('save').onclick=()=>{if(!payload)return;const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));a.href=url;a.download='aulatex-captura.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);};
