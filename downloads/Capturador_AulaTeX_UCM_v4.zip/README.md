# Capturador bibliográfico AulaTeX UCM v4

Chrome o Edge: descomprime esta carpeta; abre chrome://extensions o edge://extensions; activa Modo de desarrollador; Cargar descomprimida; selecciona la carpeta que contiene manifest.json. Fija el icono en la barra.

En la página de un artículo, pulsa la extensión y **Capturar esta página**. Copia o guarda JSON. En la web AulaTeX abre Bibliografía, pega/abre el JSON, analiza, revisa y añade. La extensión NO necesita token GitHub, NO utiliza servicios externos y NO tiene acceso permanente a todas las páginas. Solo lee el DOM accesible al pulsar gracias a activeTab. La pestaña puede contener contenido accesible con tu sesión: revisa los datos antes de compartir la captura.

Incluye detectores genéricos Highwire, Dublin Core, JSON-LD y COinS. NO incluye los traductores específicos de Zotero ni su motor. Para el resto de webs, utiliza Zotero Connector y exporta la referencia como BibTeX, RIS o CSL JSON; o revisa la ficha genérica de título + URL. No puede capturar páginas internas, todos los visores PDF, contenido de iframes ajenos ni fichas detrás de mecanismos anti-extracción.

La extensión es código fuente para carga local: no está publicada ni firmada en las tiendas. Las pruebas documentadas son Chromium y fixtures, no un barrido de todas las webs ni una certificación de Chrome/Edge.
